const jwt = require('jsonwebtoken');
exports.compara= (req, res, next) => {
    // pega o cabeçalho de autenticação da requisição
    const credencial = req.headers['autorizacao'];


    // verifica se há um cabeçalho ou não, se houver ele divide a string ('BEARER ${TOKEN}') salvando apenas o token
    const token = credencial ;

    // se não houver token retorna um erro
    if(!token){
        return res.status(401).json({ message: 'Acesso negado' });
    }

    // desserializa o token, salvando as informações do payload na requisição (req.user)
    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if(err){
            return res.status(403).json({ message: 'Token inválido' });
        }

        req.user = user;
    })

    if(req.body.idUsuario===req.user.id){
        next();
    }else{
        return res.status(400).json({ message: 'Você não tem permissão' });
    }
}