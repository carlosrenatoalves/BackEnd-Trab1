const autenticaRotas = require('./autenticaRotas');
const usuariosRotas = require('./usuariosRotas');
const compraRotas = require('./compraRotas');

module.exports = {
    autenticaRotas,
    usuariosRotas,
    compraRotas 
}