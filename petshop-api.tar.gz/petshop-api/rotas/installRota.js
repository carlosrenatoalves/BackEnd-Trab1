const express = require('express');
const criaAdmin = require('../middlewares/criaAdmin');

const installRouter = express.Router();

installRouter.get('/install', criaAdmin, (req, res) => {
    res.status(201).json({ message: 'Arquivo usuarios.json criado com sucesso!' });
});

module.exports = installRouter;
