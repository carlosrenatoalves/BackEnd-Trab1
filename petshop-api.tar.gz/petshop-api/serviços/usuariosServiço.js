const fs = require('fs').promises;

const leArquivo = async () => {
    try {
        const data = await fs.readFile('./usuarios/usuarios.json', 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        console.error("Erro ao ler arquivo de usuários:", error);
        return null;
    }
};

const escreveArquivo = async (users) => {
    try {
        await fs.writeFile('./usuarios/usuarios.json', JSON.stringify(users));
    } catch (error) {
        console.error("Erro ao escrever no arquivo de usuários:", error);
    }
};

exports.listarUsuarios = async () => {
    const users = await leArquivo();
    if (!users) return null;

    // Cria uma nova lista de usuários sem a chave 'password'
    return users.map(({ password, ...user }) => user);
};

exports.listarUsuariosId = async (id) => {
    const users = await leArquivo();
    if (!users) return null;

    const user = users.find(u => u.id === id);
    if (!user) return null;

    // Retorna o usuário sem a senha
    return { id: user.id, username: user.nome, funcao: user.funcao };
};

exports.criarUsuario = async (user) => {
    const users = await leArquivo();
    if (!users) return null;

    // Descobre o próximo id da lista
    const userId = users.length > 0 ? users[users.length - 1].id + 1 : 1;
    const newUser = { id: userId, ...user };

    users.push(newUser);
    await escreveArquivo(users);

    return newUser;
};

exports.atualizaUsuario  = async (id, updatedUser) => {
    const users = await leArquivo();
    if (!users) return null;

    const index = users.findIndex(user => user.id === id);
    if (index === -1) return null;

    // Atualiza o usuário com os dados de updatedUser
    users[index] = { ...users[index], ...updatedUser };

    await escreveArquivo(users);

    return users[index];
};

exports.removerUsuario = async (id) => {
    const users = await leArquivo();
    if (!users) return null;

    const index = users.findIndex(user => user.id === id);
    if (index === -1) return null;

    // Remove o usuário do array e retorna o usuário deletado
    const deletedUser = users.splice(index, 1)[0];

    await escreveArquivo(users);

    return deletedUser;
};
