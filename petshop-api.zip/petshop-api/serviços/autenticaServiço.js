const fs = require('fs').promises;
const path = require("path")
const geraToken = require('../utils/geraToken'); 

// Função de login
exports.login = async(nome, senha)=> {
  // Caminho do arquivo usuarios.json
  const caminhoFile = "./usuarios/usuarios.json"

  // Lê o arquivo usuarios.json
  const data = await fs.readFile(caminhoFile , 'utf-8')

    // Parse do conteúdo JSON
    const usuarios = JSON.parse(data);

    // Encontrar o usuário que corresponde ao nome e senha
    const user = usuarios.find(u => u.nome === nome && u.senha === senha);

    if (user) {
      // Usuário encontrado, gera o token
      const token = geraToken(user);
      console.log('Login bem-sucedido! Token gerado:', token);
      return token;
    } else {
      console.log('Usuário ou senha inválidos!');
      return null;
    }
  }

