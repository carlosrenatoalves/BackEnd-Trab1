const jwt = require('jsonwebtoken');

exports.authenticateToken = (req, res, next) => {
    // pega o cabeçalho de autenticação da requisição
    const credencial = req.headers['autorizacao'];

    // verifica se há um cabeçalho ou não, se houver ele divide a string ('BEARER ${TOKEN}') salvando apenas o token
    const token = credencial ;

    // se não houver token retorna um erro
    if(!token){
        return res.status(401).json({ message: 'Acesso negado' });
    }

    // desserializa o token, salvando as informações do payload na requisição (req.user)
    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if(err){
            return res.status(403).json({ message: 'Token inválido' });
        }

        req.user = user;
        next();
    })
}

exports.administradores = (req, res, next) => {
    this.authenticateToken(req, res, (err) => {
        if (err) {
            return res.status(401).json({ message: 'Acesso negado' });
        }

        // verifica se o usuário autenticado é um administrador
        if (req.user.funcao!="dono" && req.user.funcao!="gerente" ) {
            return res.status(403).json({ message: 'Acesso negado: privilégios insuficientes' });
        }

        // se o usuário é admin, passa para o próximo middleware
        next();
    });
};


exports.atendente = (req, res, next) => {
    this.authenticateToken(req, res, (err) => {
        if (err) {
            return res.status(401).json({ message: 'Acesso negado2' });
        }

        // verifica se o usuário autenticado é um administrador
        if (!req.user.funcao==="atendente" ) {
            return res.status(403).json({ message: 'Acesso negado: privilégios insuficientes' });
        }

        // se o usuário é admin, passa para o próximo middleware
        next();
    });
};

