const jwt = require('jsonwebtoken');

// Função que gera o token
function generateToken(usuario) {
  // Defina a chave secreta para assinatura do token
  const secretKey = process.env.JWT_SECRET;  // Troque por uma chave segura no seu ambiente de produção

  // O payload é o conteúdo do token, geralmente inclui informações do usuário
  const payload = {
    id: usuario.id,
    nome: usuario.nome,
    funcao: usuario.funcao,
  };

  // O tempo de expiração do token (opcional)
  const options = {
    expiresIn: process.env.JWT_TIME,  // O token vai expirar em 1 hora
  };

  // Gerando o token
  const token = jwt.sign(payload, secretKey, options);

  return token;
}

module.exports = generateToken;