const userService = require('../serviços/usuariosServiço');

exports.getAllUsers = async (req, res) => {
    try {
        const users = await userService.getAllUsers();
        return res.status(200).json(users);
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: 'Erro ao buscar usuários.' });
    }
};

exports.getUserById = async (req, res) => {
    const userId = parseInt(req.params.id, 10);

    try {
        const user = await userService.getUserById(userId);

        if (!user) {
            return res.status(404).json({ message: 'Usuário não encontrado.' });
        }

        return res.status(200).json(user);
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: 'Erro ao buscar o usuário.' });
    }
};

exports.createUser = async (req, res) => {
    try {
        const newUser = await userService.createUser(req.body);
        return res.status(201).json(newUser);
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: 'Erro ao criar o usuário.' });
    }
};

exports.updateUser = async (req, res) => {
    const userId = parseInt(req.params.id, 10);

    try {
        const updatedUser = await userService.updateUser(userId, req.body);

        if (!updatedUser) {
            return res.status(404).json({ message: 'Usuário não encontrado.' });
        }

        return res.status(200).json(updatedUser);
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: 'Erro ao atualizar o usuário.' });
    }
};

exports.deleteUser = async (req, res) => {
    const userId = parseInt(req.params.id, 10);

    try {
        const deletedUser = await userService.deleteUser(userId);

        if (!deletedUser) {
            return res.status(404).json({ message: 'Usuário não encontrado.' });
        }

        return res.status(200).json(deletedUser);
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: 'Erro ao deletar o usuário.' });
    }
};
