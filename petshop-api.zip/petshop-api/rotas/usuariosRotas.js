const express = require('express');

const controlaUsuarios = require('../controladores/controlaUsuarios');
const { validateUser} = require('../valida/validajson')
const { administradores,atendente } = require('../middlewares/autoriza')

const rotas = express.Router();

rotas.get('/atendentes', atendente,controlaUsuarios.getAllUsers);
rotas.get('/atendentes/:id',atendente, controlaUsuarios.getUserById);

rotas.get('/administradores', administradores,controlaUsuarios.getAllUsers);
rotas.get('/administradores/:id',administradores, controlaUsuarios.getUserById);
rotas.post('/administradores', administradores, validateUser, controlaUsuarios.createUser);
rotas.put('/administradores/:id', administradores, validateUser, controlaUsuarios.updateUser);
rotas.delete('/administradores/:id',administradores, controlaUsuarios.deleteUser);

module.exports = rotas;
