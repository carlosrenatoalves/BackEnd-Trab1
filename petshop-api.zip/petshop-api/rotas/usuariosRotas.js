const express = require('express');

const controlaUsuarios = require('../controladores/controlaUsuarios');
const { validateUserId, validateUser } = require('../valida/validajson') // adcionado validateUserId
const { gerente, interno } = require('../middlewares/autoriza')    // administradores, atendente

const rotas = express.Router();

/*
rotas.get('/atendentes', atendente,controlaUsuarios.getAllUsers);
rotas.get('/atendentes/:id',atendente, controlaUsuarios.getUserById);

rotas.get('/administradores', administradores,controlaUsuarios.getAllUsers);
rotas.get('/administradores/:id',administradores, controlaUsuarios.getUserById);
rotas.post('/administradores', administradores, validateUser, controlaUsuarios.createUser);
rotas.put('/administradores/:id', administradores, validateUser, controlaUsuarios.updateUser);
rotas.delete('/administradores/:id',administradores, controlaUsuarios.deleteUser);
*/

router.get('/', interno, userController.getAllUsers);           // Middleware "interno" vai verificar se é funcionario ou gerente
router.get('/:id', interno, validateUserId, userController.getUserById);
router.get('/perfil', userController.getUserProfile);           // Retorna o perfil do usuario (usar token JWT)

router.post('/cliente', interno, validateUser, userController.createCliente);
router.post('/', gerente, validateUser, userController.createUser);

router.put('/perfil', validateUser, userController.updateUserProfile); // Atualiza o perfil do usuario (requisito 6)
router.put('/cliente/:id', interno, validateUserId, validateUser, userController.updateCliente);
router.put('/:id', gerente, validateUserId, validateUser, userController.updateUser);

router.delete('/cliente/:id', interno, validateUserId, userController.deleteCliente);
router.delete('/:id', gerente, validateUserId, userController.deleteUser);

module.exports = rotas;
