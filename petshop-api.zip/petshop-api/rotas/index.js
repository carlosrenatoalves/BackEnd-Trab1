const autenticaRotas = require('./autenticaRotas');
const usuariosRotas = require('./usuariosRotas');

module.exports = {
    autenticaRotas,
    usuariosRotas
}